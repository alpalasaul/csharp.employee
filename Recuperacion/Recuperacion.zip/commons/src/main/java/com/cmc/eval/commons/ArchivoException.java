package com.cmc.eval.commons;

public class ArchivoException extends Exception {
	
	public ArchivoException(String msg) {
		super(msg);
	}

}
