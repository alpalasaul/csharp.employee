package com.cmc.eval.commons;

public class ValidationException extends Exception {
	
	public ValidationException(String msg) {
		super(msg);
	}

}
